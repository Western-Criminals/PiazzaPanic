Here are some tiles. Have fun with them. Make something awesome!
Use the tiles in an 8x8 grid, where the top right corner would be 8 pixels from the bottom and 0 pixels to the left.
Remember to use proper depth!